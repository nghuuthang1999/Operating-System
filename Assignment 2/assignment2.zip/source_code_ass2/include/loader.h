#ifndef LOADER_H
#define LOADER_H

#include "common.h"

pcb_t* load(const char * path);

#endif

